import React, { ReactElement } from 'react';

import Header from '../../components/Header';

type HomePageLayoutProps = {
    children: ReactElement;
}

const HomePageLayout: React.FC<HomePageLayoutProps> = ({ children }) => {
    return (
        <div>
            <Header />
            {children}
        </div>
    )
}

export default HomePageLayout;
