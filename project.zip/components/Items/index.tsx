import React from 'react';
import Button from '../Button';

import styles from './styles.module.css';

type ItemsProps = {
    style?: any;
}

const Items: React.FC<ItemsProps> = ({ style }) => {
    return (
        <div className={styles.itemContainer}>
            <div className={styles.itemWrap}>
                <Button title="TEXT" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn />
                <Button title="TEXT1" style={{ width: '100%', margin: '5px', height: '40px' }} disabledbtn/>
                <Button title="TEXT2" style={{ width: '100%', margin: '5px', height: '40px' }} disabledbtn />
                <Button title="TEXT" style={{ width: '100%', margin: '5px', height: '40px' }} disabledbtn />
                <Button title="TEXT" style={{ width: '100%', margin: '5px', height: '40px', marginRight: '0' }} disabledbtn />
            </div>
        </div>
    )
}

export default Items;
