import React from 'react';

import styles from './styles.module.css';

type TextareaProps = {
    placeholdertitle: string;
    style?: any;
    row?: number;
    col?: number;
    value: string;
    onChange?: (
        e:
          | React.ChangeEvent<HTMLInputElement>
          | React.ChangeEvent<HTMLTextAreaElement>
      ) => void;
}

const Textarea: React.FC<TextareaProps> = ({ placeholdertitle, style, row, col, onChange }) => {
    return (
        <div>
            <div className={styles.textareaWrap}>
            <textarea className={styles.textareaStyle} placeholder={placeholdertitle} onChange={onChange} name="test" rows={row} cols={col}>
            </textarea>
            {/* <div className={styles.iconcontainer}>
                <p>Important &nbsp;</p> <img className={styles.infoicon} src="./assects/info.png" alt="icon" />
            </div> */}
        </div>
        </div>
        

    )
}

export default Textarea;
