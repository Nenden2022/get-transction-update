import React from 'react';

import styles from './styles.module.css';
import Button from '../Button';

type ButtonProps = {
    type?: "button" | "submit" | "reset";
    style?: any;
    disabledbtn?: Boolean;
}

const Continue: React.FC<ButtonProps> = ({ type, style, disabledbtn }) => {
    return (
        <div className={styles.conContainer}>
            <div className={styles.conwrap}>
                <Button title="Continue ->" style={{ width: '100%', height: '40px' }} inactivestate />
            </div>
        </div>


    )
}

export default Continue;
