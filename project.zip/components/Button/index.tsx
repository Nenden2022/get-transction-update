import React from 'react';

import styles from './styles.module.css';

type ButtonProps = {
    type?: "button" | "submit" | "reset";
    title: String;
    style?: any;
    disabledbtn?: Boolean;
    inactivestate?: Boolean;
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
}

const Button: React.FC<ButtonProps> = ({ type, title, style, disabledbtn, inactivestate, onClick }) => {
    return (
        <button type={type || 'button'} style={style || null} className={disabledbtn ? styles.appButton1 : inactivestate ? styles.appButton2 : styles.appButton} onClick={onClick}>
            {title}
        </button>
    )
}

export default Button;
