import React from 'react';

import styles from './styles.module.css';

type BannerProps = {
    title: String;
    description:String;
    imageurl:string;
    style?: any;
}

const BannerComponent: React.FC<BannerProps> = ({ title, description, imageurl, style }) => {
    return (
        <div className={styles.bannerWrap}>
            <div className={styles.imagespeaker}>
                <img src={imageurl} alt="speaker" width={'80%'} />
            </div>
            <div className={styles.bannerTextWrap}>
                <h3>{title}</h3>
                <p>{description}</p>
            </div>
        </div>
    )
}

export default BannerComponent;

