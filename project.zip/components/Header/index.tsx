import React from 'react';
import styles from './styles.module.css';
import Button from '../Button';

const Header = () => {
    return (
        <div className={styles.headerWarp}>
            <div>
              <img src="./assects/logo.jpg" alt="logo" />
            </div>
            <div>
                <form className="search-container">
                    <input type="text" id="search-bar" placeholder="Search" />
                </form>
            </div>
            <div>
                <Button type='button' title="Sign In" style={{padding: '5px 20px'}}/>
            </div>

        </div>
    )
}

export default Header;
