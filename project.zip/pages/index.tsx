import React, { useState } from 'react';
import { useRouter } from 'next/router';

import HomePageLayout from '../layouts/HomePageLayout';
import BannerComponent from '../components/Banner';
import Button from '../components/Button';
import Textarea from '../components/Textarea';
import styles from './styles.module.css';

const HomePage = () => {
  const router = useRouter();
  const [isclickedbtn1, setIsclickedbtn1] = useState(false);
  const [isclickedbtn2, setIsclickedbtn2] = useState(false);
  const [isclickedbtn3, setIsclickedbtn3] = useState(false);
  const [isclickedbtn4, setIsclickedbtn4] = useState(false);
  const [isclickedbtn5, setIsclickedbtn5] = useState(false);
  const [isactivebtn, setIsactivebtn] = useState(false);
  const [text, setText] = useState('');
  const goNextpage = () => {
    if (text.length > 0) {
      router.push({ pathname: '/contact', query: { 'textdata':text } })
    }
  }
  const clicked1 = (value: number) => {
    if (value === 1) {
      setIsclickedbtn1(true)
      setIsclickedbtn2(false)
      setIsclickedbtn3(false)
      setIsclickedbtn4(false)
      setIsclickedbtn5(false)
      setIsactivebtn(true)
    } else if (value === 2) {
      setIsclickedbtn1(false)
      setIsclickedbtn2(true)
      setIsclickedbtn3(false)
      setIsclickedbtn4(false)
      setIsclickedbtn5(false)
      setIsactivebtn(true)
    } else if (value === 3) {
      setIsclickedbtn1(false)
      setIsclickedbtn2(false)
      setIsclickedbtn3(true)
      setIsclickedbtn4(false)
      setIsclickedbtn5(false)
      setIsactivebtn(true)
    } else if (value === 4) {
      setIsclickedbtn1(false)
      setIsclickedbtn2(false)
      setIsclickedbtn3(false)
      setIsclickedbtn4(true)
      setIsclickedbtn5(false)
      setIsactivebtn(true)
    } else if (value === 5) {
      setIsclickedbtn1(false)
      setIsclickedbtn2(false)
      setIsclickedbtn3(false)
      setIsclickedbtn4(false)
      setIsclickedbtn5(true)
      setIsactivebtn(true)
    }
  }

  return (
    <HomePageLayout>
      <div >
        <BannerComponent imageurl="./assects/speaker.jpg" title="Make an Announcement" description="Type the text portion of your message (no files alllowed) that you want to verify. Your announcements are public by default." />
        <Textarea placeholdertitle="Paste your message here" row={10} value={text} onChange={(e) => setText(e.target.value)} />
        <div className={styles.itemContainer}>
          <div className={styles.itemWrap}>
            {
              isclickedbtn1 ? <Button title="TEXT" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} onClick={() => clicked1(1)} /> :
                <Button title="TEXT" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn onClick={() => clicked1(1)} />
            }
            {
              isclickedbtn2 ? <Button title="TEXT1" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} onClick={() => clicked1(2)} /> :
                <Button title="TEXT1" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn onClick={() => clicked1(2)} />
            }
            {
              isclickedbtn3 ? <Button title="TEXT2" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} onClick={() => clicked1(3)} /> :
                <Button title="TEXT2" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn onClick={() => clicked1(3)} />
            }
            {
              isclickedbtn4 ? <Button title="TEXT3" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} onClick={() => clicked1(4)} /> :
                <Button title="TEXT3" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn onClick={() => clicked1(4)} />
            }
            {
              isclickedbtn5 ? <Button title="TEXT4" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} onClick={() => clicked1(5)} /> :
                <Button title="TEXT4" style={{ width: '100%', margin: '5px', height: '40px', marginLeft: '0' }} disabledbtn onClick={() => clicked1(5)} />
            }
          </div>
        </div>
        <div className={styles.conContainer}>
          <div className={styles.conwrap}>
            {
              isactivebtn ? <Button title="Continue ->" style={{ width: '100%', height: '40px' }} onClick={() => goNextpage()} /> :
                <Button title="Continue ->" style={{ width: '100%', height: '40px' }} inactivestate />
            }
          </div>
        </div>
      </div>
    </HomePageLayout>
  )
}

export default HomePage;
