import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

import HomePageLayout from '../../layouts/HomePageLayout';
import BannerComponent from '../../components/Banner';
import Button from '../../components/Button';
import Textarea from '../../components/Textarea';
import styles from './styles.module.css';

const Contact = () => {
    const router = useRouter();
    const [textData, setTextData] = useState<any>('');
    const [text, setText] = useState<any>('');
    useEffect(() => {
        let data: string | string[] | undefined = router.query.textdata
        console.log('ddddd', data)
        setText(data)
    }, [])

    const goNextpage = () => {
        console.log('clicked')
    }

    const goPrevpage = () => {
        router.push('/')
    }

    return (
        <HomePageLayout>
            <div >
                <BannerComponent imageurl="./assects/speaker.jpg" title="Make an Announcement" description="Type the text portion of your message (no files alllowed) that you want to verify. Your announcements are public by default." />
                <Textarea placeholdertitle="Paste your message here" row={10} value={text} onChange={(e) => setText(e.target.value)} />
                <div className={styles.itemContainer}>
                    <div className={styles.itemWrap}>
                        <Button title="TEXT" style={{ width: '20%', margin: '5px', height: '40px', marginLeft: '0' }} />
                    </div>
                </div>
                <div className={styles.itemContainer}>
                    <div className={styles.itemWrap}>
                        <form className={styles.ethWrap} >
                            <input type="text" className={styles.inputbox} placeholder="Enter Amount" />
                            <div className={styles.ethBtn}>
                                <Button title="ETH" style={{ padding: '5px' }} />
                            </div>
                        </form>
                    </div>
                </div>
                <div className={styles.conContainer}>
                    <div className={styles.conwrap}>
                        <Button title="<- Back" style={{ width: '100%', height: '40px', marginRight: '10px' }} disabledbtn onClick={() => goPrevpage()} />
                        <Button title="Continue ->" style={{ width: '100%', height: '40px', marginLeft: '10px' }} onClick={() => goNextpage()} />
                    </div>
                </div>
            </div>
        </HomePageLayout >
    )
}

export default Contact;
